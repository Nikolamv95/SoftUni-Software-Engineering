﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballTeamGenerator.Common
{
    public class CommonExcMessages
    {
        public const string InvalidNameExcMsg = "A name should not be empty.";
    }
}
